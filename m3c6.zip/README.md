TIPO landing page
servicios
opiniones
formulario de contacto
boton para descargar un menu de la cafeteria
slider con imagenes
opiniones y comentarios
y que la pagina tenga un mapa de las sucursales
